// pointer_eg4.c
//
// ポインタ変数　サンプルプログラム４
// 〜基本動作の関数化 ポインタ引数　返り値なしの関数版
//
// Created by Fumito Higuchi
// Date: 2017-06-12.

#include <stdio.h>
#include <stdlib.h> // malloc(), rand()を利用するのに必要
#include <time.h>   // srand()の引数にシステムクロックを利用するのに必要

struct cell {
    struct cell *next;
    int val;
};

void printList(struct cell *p);
void appendCell(struct cell *p, int value);
void prependCell(struct cell *p, int value);
//struct cell * prependCell(struct cell *p, int value);
void insertCell(struct cell *p, int index, int value);
void deleteCell(struct cell *p, int index);
void deleteValue(struct cell *p, int value);

int main(void){

  srand((unsigned)time(NULL)); // 乱数の初期化
  int v;  
    
    struct cell *p, *q, top;
    p = &top;
    top.next = NULL;      // 最初のセルを設定（後続のセルは無い）
    top.val  = rand()%32; // = 0;　乱数で val の値を設定　
                          // 値が大きくなり過ぎないように剰余を使っている
    int i = 1;            // 作成するセルの個数を数えるためのカウンタ変数
    while (i < 10){
      appendCell(p, rand()%32);
      //      prependCell(p, rand()%32);
      //      //      p = prependCell(p, rand()%32);
      i++;
    }
    
    //p = &top;
    printList(p);
    printf("\n線形リストの出力終了\n生成できる乱数の最大値：　%d\n", RAND_MAX);
    insertCell(p, 9, 777);
    insertCell(p, 13, 999);
    printList(p);
    deleteCell(p, 0);
    printList(p);
    deleteCell(p, 1);
    printList(p);
    deleteValue(p, 357);
    printList(p);
}

void printList(struct cell *p){
    while (p != NULL) {
      //      printf("%i at %p, conecting to %p\n", p->val, p, p->next);
      printf("%i\n", p->val);
      p = p -> next;
    }
}

void appendCell(struct cell *p, int value){
  struct cell *q;
  while (p->next != NULL) { p = p->next; }
  q = (struct cell *)malloc(sizeof(struct cell));
  q->next = p->next;
  q->val = value;
  p->next = q;
}

void prependCell(struct cell *p, int value){
  struct cell *q;
  q = (struct cell *)malloc(sizeof(struct cell));
  q->next = p->next;
  q->val = p->val;
  p->next = q;
  p->val = value;
}

/*
struct cell * prependCell(struct cell *p, int value){
  struct cell *q;
  q = (struct cell *)malloc(sizeof(struct cell));
  q->next = p;
  q->val = value;
  return q;  
}
*/

void insertCell(struct cell *p, int index, int value){
  struct cell *q;
  int count = 0;
  if (index == 0) { prependCell(p, value); }
  else {
    while (count+1 < index && p->next != NULL) { p = p->next; count++; }
    q = (struct cell *)malloc(sizeof(struct cell));
    q->next = p->next;
    q->val = value;
    p->next = q;
  }
}

void deleteCell(struct cell *p, int index){
  struct cell *q = NULL;
  int count = 0;
  if (index < 1) {
    q = p->next;
    //    *p = *q;
    p->next = q->next;
    p->val = q->val;
    free(q);
  } else {
    while (count+1 < index && p->next != NULL) { p = p->next; count++; }
    if (p->next != NULL){
      q = p->next;
      p->next = q->next;
      free(q);
    } // else do nothing;
  }
}


void deleteValue(struct cell *p, int value){
  struct cell *q = p;
  while (q != NULL && q->val != value) { p = q; q = q->next;}
  if (q == p) {
    q = p->next;
    p->next = q->next;
    p->val = q->val;
    free(q);
  } else if (q != NULL){
    p->next = q->next;
    free(q);
  }
}


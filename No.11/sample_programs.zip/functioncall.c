/*

reference: https://www.eskimo.com/~scs/cclass/int/sx8.html
           Chapter 22: Pointers to Pointers

author: Fumito Higuchi
date: 2017-06-22

*/

#include <stdio.h>
#include <stdlib.h>

void f(int x);
void pf(int *px);
void ppf(int **ppx);

int j = 5;

int main(void){
  int i = 3;
  int *pi;
  int **ppi;

  f(i);
  printf("i = %i\n",       i);

  pf(pi);
  printf("*pi = %i\n",   *pi);

  ppi = &pi; // ppi が NULLだと *ppi などへの代入もできない Segment Fault の原因
  ppf(ppi);
  printf("**ppi = %i\n", **ppi);  

  return 0;
}

void f(int x) {
  x = 5;
}

void pf(int *px) {
  *px = 6;
}

void ppf(int **ppx) {
  int *p = (int *)malloc(sizeof(int));
  if (p != NULL) { *p = 7; } else {printf("ERROR");}
  *ppx = p;
}

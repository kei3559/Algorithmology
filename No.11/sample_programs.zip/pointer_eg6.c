// pointer_eg6.c
//
// ポインタ変数　サンプルプログラム５
// 〜基本動作の関数化 ポインタのポインタを引数とする関数
//
// Created by Fumito Higuchi
// Date: 2017-06-25.

#include <stdio.h>
#include <stdlib.h> // malloc(), rand()を利用するのに必要
#include <time.h>   // srand()の引数にシステムクロックを利用するのに必要

struct cell {
    struct cell *next;
    int val;
};

void printList(struct cell **ppT);
struct cell * createCell(int value);
void appendCell(struct cell **ppT, struct cell *p);
void prependCell(struct cell **ppT, struct cell *p);
void insertCell(struct cell **ppT, struct cell *p, int index);
void deleteCell(struct cell **ppT, int index);
void deleteValue(struct cell **ppT, int value);

int main(void){

  srand((unsigned)time(NULL)); // 乱数の初期化
  int v;  
    
    struct cell *p, *top, **ppT;
    ppT = &top;
    top = NULL;      // 線形リストの初期状態


    int i = 0;            // 作成するセルの個数を数えるためのカウンタ変数
    while (i < 10){
      p = createCell(rand()%32);
      //      printf("%i at %p, conecting to %p\n", p->val, p, p->next);
      appendCell(ppT, p);
      //      prependCell(ppT, p);
      i++;
    }
    
    printList(ppT);
    //    printf("\n線形リストの出力終了\n生成できる乱数の最大値：　%d\n", RAND_MAX);
    p = createCell(777); insertCell(ppT, p, 9);
    p = createCell(999); insertCell(ppT, p, 13);
    printList(ppT);
    deleteCell(ppT, 0);
    printList(ppT);
    deleteCell(ppT, 5);
    printList(ppT);
    deleteValue(ppT, 777);
    printList(ppT);
}

void printList(struct cell **ppT){
    while (*ppT != NULL) {
      printf("%i\n", (*ppT)->val);
      ppT = &((*ppT)->next);                    // セルではなくポインタ部分を追いかける
    }
}

struct cell * createCell(int value){            // 生成したセルへのポインタを返す関数
  struct cell *p;
  p = (struct cell *)malloc(sizeof(struct cell));
  p->val = value;
  p->next = NULL;
  return p;
}

void appendCell(struct cell **ppT, struct cell *p){
  while (*ppT != NULL) { ppT = &((*ppT)->next); }
  *ppT = p;
}

void prependCell(struct cell **ppT, struct cell *p){
  p->next = *ppT;
  *ppT = p;
}

void insertCell(struct cell **ppT, struct cell *p, int index){
  int count = 0;
  if (index < 1) { prependCell(ppT, p); } // リストの先頭へ挿入
  else {
    while (++count < index && (*ppT)->next != NULL) { ppT = &((*ppT)->next); }
    p->next = (*ppT)->next;
    (*ppT)->next = p;
  }
}

void deleteCell(struct cell **ppT, int index){
  struct cell *q;
  int count = 0;
  if (*ppT != NULL){
    if (index < 1) {
      q = *ppT;
      *ppT = q->next;
    } else {
      while (++count < index && (*ppT)->next != NULL) { ppT = &((*ppT)->next); }
      q = (*ppT)->next;
      (*ppT)->next = q->next;
    }
  free(q);
  }
}

void deleteValue(struct cell **ppT, int value){
  struct cell *p, *q;
  if (*ppT != NULL){
    p = *ppT;
    while (*ppT != NULL && (*ppT)->val != value) { p = *ppT; ppT = &((*ppT)->next);}
    if (p == *ppT) {                   // 先頭が該当するときの削除
      q = (*ppT)->next;
    } else if (*ppT != NULL){          // ２番目以降が該当するときの削除
      p->next = (*ppT)->next;
      q = *ppT;
    }
    free(q);
  }
}




// pointer_eg5.c
//
// ポインタ変数　サンプルプログラム５
// 〜基本動作の関数化 ポインタ引数　返り値ありの関数版
//
// Created by Fumito Higuchi
// Date: 2017-06-12.

#include <stdio.h>
#include <stdlib.h> // malloc(), rand()を利用するのに必要
#include <time.h>   // srand()の引数にシステムクロックを利用するのに必要

struct cell {
    struct cell *next;
    int val;
};

void printList(struct cell *p);
struct cell * createCell(int value);
struct cell * appendCell(struct cell *top, struct cell *p);
struct cell * prependCell(struct cell *top, struct cell *p);
struct cell * insertCell(struct cell *top, struct cell *p, int index);
struct cell * deleteCell(struct cell *top, int index);
struct cell * deleteValue(struct cell *top, int value);

int main(void){

  srand((unsigned)time(NULL)); // 乱数の初期化
  int v;  
    
    struct cell *p, *q, *top;
    top = NULL;      // 線形リストの初期状態


    int i = 0;            // 作成するセルの個数を数えるためのカウンタ変数
    while (i < 10){
      p = createCell(rand()%32);
      //      printf("%i at %p, conecting to %p\n", p->val, p, p->next);
      //      top = appendCell(top, p);
      //      printf("%i at %p, conecting to %p\n", top->val, top, top->next);
      top = prependCell(top, p);
      i++;
    }
    
    //p = &top;
    printList(top);
    printf("\n線形リストの出力終了\n生成できる乱数の最大値：　%d\n", RAND_MAX);
    p = createCell(777); top = insertCell(top, p, 9);
    p = createCell(999); top = insertCell(top, p, 13);
    printList(top);
    top = deleteCell(top, 0);
    printList(top);
    top = deleteCell(top, 1);
    printList(top);
    top = deleteValue(top, 777);
    printList(top);
}

void printList(struct cell *p){
    while (p != NULL) {
      //      printf("%i at %p, conecting to %p\n", p->val, p, p->next);
      printf("%i\n", p->val);
      p = p -> next;
    }
}

struct cell * createCell(int value){
  struct cell *p;
  p = (struct cell *)malloc(sizeof(struct cell));
  p->val = value;
  p->next = NULL;
  return p;
}

struct cell * appendCell(struct cell *top, struct cell *p){
  struct cell *q;
  if (top == NULL) { return p; } // リストが空のとき
  else {                         // リストが空でないとき
    q = top;
    while (q->next != NULL) { q = q->next; } // リスト最後までたどる
    q->next = p;
    return top;
  }
}

struct cell * prependCell(struct cell *top, struct cell *p){
  struct cell *q;
  p->next = top;
  return p;  
}

struct cell * insertCell(struct cell *top, struct cell *p, int index){
  struct cell *q;
  int count = 0;
  if (index < 1) { return prependCell(top, p); } // リストの先頭へ挿入
  else {
    q = top;
    while (count+1 < index && q->next != NULL) { q = q->next; count++; }
    p->next = q->next;
    q->next = p;
    return top;
  }
}

struct cell * deleteCell(struct cell *top, int index){
  struct cell *p, *q = NULL;
  int count = 0;
  if (top != NULL){
    if (index < 1) { // 先頭から削除
      q = top;
      top = q->next;
      free(q);
    } else {         // ２番目以降で探して削除
      p = top;
      while (count+1 < index && p->next != NULL) { p = p->next; count++; }
      if (p->next != NULL){
	q = p->next;
	p->next = q->next;
	free(q);
      } // else do nothing;
    }
  }
  return top;
}

struct cell * deleteValue(struct cell *top, int value){
  struct cell *p, *q;
  if (top != NULL){
    p = top; q = top;
    while (q != NULL && q->val != value) { p = q; q = q->next;}
    if (q == p) {                   // 先頭が該当するときの削除
      p = q->next;
      free(q);
      return p;
    } else if (q != NULL){          // ２番目以降が該当するときの削除
      p->next = q->next;
      free(q);
    }
  }
  return top;
}
  



